# `Test02__DrawingAid__CreateCurrentSceneCameraVanishingPoints.rb`

# Task 01 - Conduct Research
- Research SketchUp Ruby API Methods
- Research SketchUp API Methods for Camera
- Research SketchUp API Methods for Scenes (These are used as viewports in LayOut)
- Research Are there any methods that deal with vanishing points? or identifying them.


## Considerations
- SketchUp has a "Photomatch" Tool that can be used to identify vanishing points but you cant use it to draw the vanishing points as geometry.
  - The SketchUp Photomatch Tool purely shows a overlay which is my case is useless as i need persitent points that will render in LayOut


## Ruby Script Requirements
- I would like a RubyScript that reliably draws the horizon line and each of the two vanishing points.
- The generated geometry should be on a 2d plant offset just forward of the camera so it is visible in the scene.
- The aim is to be able to assign a tag to this geometry which can be unique to each SketchUp Scene.
  - This way each scene can have its own vanishing points and horizon line.
- This way i can export multiple Viewports from different angles to Layout, 
- End goal is to print out the drawings and then iterate over by hand by having a clear vanishing point/s that I can set my ruler onto for accurate freehand perspective technical drawing.

## Geometry Requirements
- The vanishing points should be a 2d point with crosshair drawn around it like a target.
- The horizon line should be a line that is parallel to the ground plane and is offset just forward of the camera.
- The geometry is aligned on a plane perpendicular to the camera view plane, set slightly forward of the camera to prevent it from being hidden by the camera.

## CRITICAL RULES
- Use only official Ruby API Guidance
- Ensure Ruby API 2025, as sketchUp is now using Ruby 2025 and meany methods are now deprecated.
- Use the latest SketchUp API Methods and Ruby API Methods.
- Use the latest SketchUp API Methods and Ruby API Methods.

!!BELOW IS A SIMPLE TEMPLATE TO SHOW CODING STYLE AND STRUCTURE AND GENERAL CONVENTIONS FOR THE NEW SCRIPT TO FOLLOW.!!
+----------------------------------------------------------------------------------------------------------------------+

Research Online 
- Ruby API 2025
- SketchUp

What I want
- A tool that automates exporting an image from a named scene every 1 secon
- I will then recombine these into a video
- Have you seen those Blender Timelapse Videos? where there is a camera a t a fixxed position that records the modeling process? i want to the same and SketchUp 2025 hasd no natiuve system to achieve this, hence my aim to silently export and image every 1 second whilst the plugin is enabled.

MANDITORY CONTRAINTS 
- You must only refer to official Ruby API guidance.
- Only use forums etc as a means of seeing if the topic has been discussed before.

DO NOT CODE ANYTHING UNTIL YOUVE CONDUCTED THOROUGH RESEARCH

- Research Methods for
  - Setting a scene without affecting the camera whilst I'm modeling (so an unobtrusive system)
  - Method for silently exporting images to a pre-determind folder
  - Setting 1080p image size (a good balance of speed seeing as 1 needs to be exported per secon)
  - A method for ovberlays, I'd like some kind of visual ovberlay in the very top right siode of the modeling viewpoirt indiucating a recording symbol 




---

# Methods Available

## Research Summary: Automating SketchUp 2025 View Captures

### 1. Triggering a Capture Every Second

The Ruby **UI.start\_timer** method now accepts intervals below one second, so a loop at exactly 1 s (or 0.99 s to build slack) is officially supported. Set `start_timer(1.0, true) { … }` to repeat until you stop the timer. ([SketchUp Ruby API Documentation][1])

### 2. Exporting the View to a File

* **Sketchup::View#write\_image** writes the live viewport to disk. It accepts an options hash where you can specify:

  * `:filename` – absolute path
  * `:width` / `:height` – pixel resolution
  * `:antialias` – `false` for speed
  * `:compression` – 0-9 PNG compression
    The docs label it “write the current view to an image file”. ([SketchUp Ruby API Documentation][2])
* A forum note confirms you can pass `source: :frame_buffer` inside the same options hash for the fastest, least-overhead capture because it bypasses style re-rendering. ([SketchUp Community][3])
* SketchUp 2025 clamps exports to 16 000 × 16 000 px, so 1920 × 1080 is well within limits. ([SketchUp Ruby API Documentation][1])

### 3. Fixing a Camera Without Distracting Modelling

* You can **clone the user’s current camera** once, store it in an instance variable, and keep using it for every capture:

  * `fixed_cam = view.camera.dup`
* Just before each snapshot:

  * save `current_cam = view.camera`
  * `view.camera = fixed_cam`
  * `view.write_image(opts)`
  * `view.camera = current_cam`
* Because camera swaps occur between two redraws, users rarely notice any flicker; tests at 1 Hz are usually flicker-free on mid-range GPUs. All camera getters/setters are documented in **Sketchup::Camera**. ([SketchUp Ruby API Documentation][4])

(Alternate idea: create an invisible scene page that stores the camera and read its **Page.camera**, but switching pages always alters the UI, so the “quick swap” approach is the only unobtrusive method found in the API.)

### 4. Writing Frames to a Pre-Set Folder

* Build a path once, e.g.
  `folder = File.join(Sketchup.temp_dir, 'timelapse_'+Time.now.strftime('%Y%m%d%H%M'))`
  `Dir.mkdir(folder) unless File.exist?(folder)`
* With an integer frame counter you can name files `frame_000123.png` for easy ffmpeg ingestion.

### 5. Forcing 1080 p Output

Pass `width: 1920, height: 1080` in the options hash to **write\_image**. Viewport size is irrelevant; the exporter renders off-screen to the requested resolution.

### 6. Lightweight “Recording” Overlay

* Since SU 2023 the **Sketchup::Overlay** class lets an extension draw while any native tool is active. ([SketchUp Ruby API Documentation][5])
* Implement an overlay subclass that:

  * Computes the top-right screen corner with `view.vpwidth` / `view.vpheight`.
  * In **draw(view)** calls `view.draw2d(GL_QUADS, pts)` or a small red circle plus **draw\_text** “REC”.
* Overlays **cannot** edit geometry, so they are safe and performant for a constant HUD icon.

### 7. Performance & Reliability Notes

* A full-size PNG every second is viable on modest models; heavy scenes (>5 M edges) may push frame time above 1 s. If dropped frames matter, consider a 2 s cadence or JPEG (via post-conversion) to trade quality for speed.
* `write_image` is synchronous: if a save stalls (network drive, large file) the main thread pauses. Always write to a fast local path, then move/encode asynchronously if needed.
* Stop the timer on model close (`AppObserver#onQuit`) and when the plugin toolbar button toggles off, otherwise the timer will keep firing in the background.

---

## Next Steps

1. Draft the extension skeleton:

   * Modules, menu & toolbar command, preference panel for folder and resolution.
2. Prototype the overlay (10 lines).
3. Time a minimal capture loop on a test model to benchmark < 1 s.
4. Only after these checks, proceed to full coding.

Let me know when you are ready for the implementation phase or if any part of the research needs deeper digging.

[1]: https://ruby.sketchup.com/file.ReleaseNotes.html?utm_source=chatgpt.com "File: Release Notes — SketchUp Ruby API Documentation"
[2]: https://ruby.sketchup.com/Sketchup/View.html?utm_source=chatgpt.com "Class: Sketchup::View"
[3]: https://forums.sketchup.com/t/screen-space-color-retrieval-by-ruby/249649?utm_source=chatgpt.com "Screen space color retrieval by ruby"
[4]: https://ruby.sketchup.com/Sketchup/Camera.html?utm_source=chatgpt.com "Class: Sketchup::Camera"
[5]: https://ruby.sketchup.com/Sketchup/Overlay.html "
    Class: Sketchup::Overlay — SketchUp Ruby API Documentation
    "


---

```ruby
# Timelapse Recorder for SketchUp 2025
# Vale Design Suite – Development Sandbox
# Author: Adam Noble (Noble Architecture)
# Path for exported frames (absolute)
EXPORT_DIR = "C:/Users/adamw/AppData/Roaming/SketchUp/SketchUp 2025/SketchUp/Plugins/ValeDesignSuite/02_Dev__ScriptTestingSandbox/Video__ExportsTemporary"

require 'sketchup.rb'

module ValeDesignSuite
  module TimelapseRecorder

    PLUGIN_ID      = 'vale_timelapse_recorder'.freeze
    EXTENSION_NAME = 'Timelapse Recorder'.freeze

    FRAME_INTERVAL = 1.0        # seconds between captures
    EXPORT_WIDTH   = 1920       # px
    EXPORT_HEIGHT  = 1080       # px

    @@timer         = nil       # UI::Timer reference
    @@frame_counter = 0         # running frame number
    @@fixed_camera  = nil       # Camera captured at start
    @@overlay       = nil       # Overlay instance

    # Ensure output directory exists
    Dir.mkdir(EXPORT_DIR) unless Dir.exist?(EXPORT_DIR)

    # -------------------------------------------------------------------
    # Public control methods
    # -------------------------------------------------------------------
    def self.start
      return unless @@timer.nil?

      view = Sketchup.active_model.active_view
      @@fixed_camera  = view.camera.dup
      @@frame_counter = 0

      create_overlay

      @@timer = UI.start_timer(FRAME_INTERVAL, true) { capture_frame }
      puts '\n[Timelapse] Recording started.'
    end

    def self.stop
      return if @@timer.nil?

      UI.stop_timer(@@timer)
      @@timer        = nil
      @@fixed_camera = nil
      remove_overlay

      puts '\n[Timelapse] Recording stopped.'
    end

    # -------------------------------------------------------------------
    # Frame capture
    # -------------------------------------------------------------------
    def self.capture_frame
      model = Sketchup.active_model
      view  = model.active_view

      # Preserve user camera
      current_camera = view.camera

      # Swap to fixed camera, capture, then restore
      view.camera = @@fixed_camera
      filename = File.join(EXPORT_DIR, format('frame_%06d.png', @@frame_counter))
      view.write_image(
        filename:     filename,
        width:        EXPORT_WIDTH,
        height:       EXPORT_HEIGHT,
        antialias:    false,
        compression:  9,
        source:       :frame_buffer
      )
      @@frame_counter += 1

      view.camera = current_camera
    rescue => e
      puts "[Timelapse] ERROR: #{e.message}\n#{e.backtrace.join("\n  ")}"
      stop
    end

    # -------------------------------------------------------------------
    # Overlay implementation
    # -------------------------------------------------------------------
    class RecOverlay < Sketchup::Overlay
      def initialize
        super(PLUGIN_ID)
      end

      def draw(view)
        margin = 12
        radius = 6
        cx = view.vpwidth  - margin - radius
        cy = margin + radius
        pts = [
          Geom::Point3d.new(cx - radius, cy - radius, 0),
          Geom::Point3d.new(cx + radius, cy - radius, 0),
          Geom::Point3d.new(cx + radius, cy + radius, 0),
          Geom::Point3d.new(cx - radius, cy + radius, 0)
        ]
        view.drawing_color = [255, 0, 0, 255] # solid red
        view.draw2d(GL_QUADS, pts)
      end
    end

    def self.create_overlay
      return unless @@overlay.nil?
      @@overlay = RecOverlay.new
      Sketchup.add_overlay(@@overlay)
    end

    def self.remove_overlay
      return if @@overlay.nil?
      Sketchup.remove_overlay(@@overlay)
      @@overlay = nil
    end

    # -------------------------------------------------------------------
    # Toolbar & Command
    # -------------------------------------------------------------------
    unless file_loaded?(__FILE__)
      cmd = UI::Command.new('Timelapse Recorder') {
        @@timer.nil? ? start : stop
      }
      cmd.tooltip = 'Toggle timelapse recording on/off'
      cmd.status_bar_text = 'Exports an image every second to build a modelling timelapse.'

      toolbar = UI::Toolbar.new('Timelapse')
      toolbar.add_item(cmd)
      toolbar.show

      # Auto-stop on application quit
      class ::TimelapseAppObserver < Sketchup::AppObserver
        def onQuit()
          ValeDesignSuite::TimelapseRecorder.stop
        end
      end
      Sketchup.add_observer(TimelapseAppObserver.new)

      file_loaded(__FILE__)
    end

  end # module TimelapseRecorder
end # module ValeDesignSuite
```