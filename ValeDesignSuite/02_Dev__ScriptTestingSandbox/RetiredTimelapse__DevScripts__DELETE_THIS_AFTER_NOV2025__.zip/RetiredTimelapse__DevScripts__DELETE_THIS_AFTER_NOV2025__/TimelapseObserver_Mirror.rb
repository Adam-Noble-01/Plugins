# =============================================================================
# TIMELAPSE OBSERVER - MIRROR INSTANCE SCRIPT
# =============================================================================
#
# FILE       : TimelapseObserver_Mirror.rb
# MODULE     : ValeDesignSuite::TimelapseObserver
# AUTHOR     : Adam Noble - Noble Architecture
# PURPOSE    : Observes main model and records timelapse in separate instance
# CREATED    : 2025
#
# DESCRIPTION:
# - Run this in a SEPARATE SketchUp instance (the mirror file)
# - Monitors the main model file for changes
# - Reloads content when main model is saved
# - Captures frames from consistent camera angle
# - No impact on main model performance
#
# USAGE:
# 1. Open your main model and start TimelapseSaver
# 2. Open a new SketchUp instance
# 3. Run this script and select your main model file
# 4. The mirror will update and record automatically
#
# =============================================================================

require 'sketchup.rb'
require 'fileutils'

module ValeDesignSuite
  module TimelapseObserver

    # MODULE CONSTANTS | Configuration Settings
    # ------------------------------------------------------------
    CHECK_INTERVAL          =   2.0                                              # <-- Check for changes every 2 seconds
    SCENE_NAME              =   'TimelapseVideo__HelperScene'.freeze             # <-- Scene for consistent view
    WIDTH_PX                =   1920                                             # <-- Export width
    HEIGHT_PX               =   1080                                             # <-- Export height
    EXPORT_DIR              =   'C:/Users/adamw/AppData/Roaming/SketchUp/SketchUp 2025/SketchUp/Plugins/ValeDesignSuite/02_Dev__ScriptTestingSandbox/Video__ExportsTemporary'.tr('\\','/')
    EXTENSION_ID            =   'vale_design_suite.timelapse_observer'.freeze    # <-- Extension ID
    # ------------------------------------------------------------

    # MODULE VARIABLES | State Management
    # ------------------------------------------------------------
    @@timer                 =   nil                                              # <-- Timer reference
    @@source_path           =   nil                                              # <-- Path to main model
    @@last_mtime            =   Time.at(0)                                       # <-- Last modification time
    @@frame_counter         =   0                                                # <-- Frame number
    @@instance              =   nil                                              # <-- Component instance
    @@scene_page            =   nil                                              # <-- Scene reference
    @@overlay               =   nil                                              # <-- REC indicator
    @@reload_count          =   0                                                # <-- Reload counter
    # ------------------------------------------------------------

    FileUtils.mkdir_p(EXPORT_DIR) unless Dir.exist?(EXPORT_DIR)                 # <-- Ensure export dir exists

    # -----------------------------------------------------------------------------
    # REGION | Scene Management Functions
    # -----------------------------------------------------------------------------

        # FUNCTION | Create or Get Helper Scene
        # ------------------------------------------------------------
        def self.ensure_helper_scene
            model = Sketchup.active_model
            scene = model.pages[SCENE_NAME]                                      # <-- Check for existing scene
            
            unless scene
                puts "[TimelapseObserver] Creating scene: #{SCENE_NAME}"
                
                # Create scene with good default view
                scene = model.pages.add(SCENE_NAME)                              # <-- Add new scene
                
                # Set up camera for nice 3/4 view
                camera = model.active_view.camera
                bounds = model.bounds
                center = bounds.center                                           # <-- Model center
                diagonal = bounds.diagonal                                       # <-- Model size
                
                # Position camera at nice angle
                eye_distance = diagonal * 2.0                                    # <-- Camera distance
                eye = Geom::Point3d.new(
                    center.x + eye_distance * 0.7,                              # <-- X offset
                    center.y - eye_distance * 0.7,                              # <-- Y offset  
                    center.z + eye_distance * 0.5                               # <-- Z offset
                )
                
                camera.set(eye, center, Z_AXIS)                                  # <-- Set camera
                camera.perspective = true                                        # <-- Perspective view
                camera.fov = 35                                                  # <-- Field of view
                
                scene.update(PAGE_USE_ALL)                                       # <-- Save all properties
                puts "[TimelapseObserver] Scene created with default view"
            end
            
            model.pages.selected_page = scene                                    # <-- Activate scene
            return scene
        end
        # ------------------------------------------------------------

    # endregion -------------------------------------------------------------------

    # -----------------------------------------------------------------------------
    # REGION | Model Loading Functions
    # -----------------------------------------------------------------------------

        # FUNCTION | Load Main Model as Component
        # ------------------------------------------------------------
        def self.load_model_content
            return unless @@source_path && File.exist?(@@source_path)            # <-- Check file exists
            
            # Check if file has been modified
            current_mtime = File.mtime(@@source_path) rescue nil
            return if current_mtime == @@last_mtime                             # <-- Skip if unchanged
            
            model = Sketchup.active_model
            model.start_operation('Update Timelapse', true)                      # <-- Start operation
            
            begin
                # Clear existing content
                if @@instance && @@instance.valid?
                    model.entities.erase_entities(@@instance)                    # <-- Remove old instance
                end
                model.definitions.purge_unused                                   # <-- Clean up definitions
                
                # Load new content
                definition = model.definitions.load(@@source_path)               # <-- Load model
                @@instance = model.entities.add_instance(definition, IDENTITY)   # <-- Add instance
                
                # Update tracking
                @@last_mtime = current_mtime                                     # <-- Update timestamp
                @@reload_count += 1                                              # <-- Increment counter
                
                # Frame the model if first load
                if @@reload_count == 1
                    model.active_view.zoom_extents                               # <-- Zoom to fit
                    @@scene_page.update(PAGE_USE_CAMERA) if @@scene_page         # <-- Update scene
                end
                
                model.commit_operation                                           # <-- Commit changes
                
                # Capture frame after successful reload
                capture_frame                                                    # <-- Export image
                
            rescue => e
                model.abort_operation                                            # <-- Rollback on error
                puts "[TimelapseObserver] Load error: #{e.message}"
            end
        end
        # ------------------------------------------------------------

    # endregion -------------------------------------------------------------------

    # -----------------------------------------------------------------------------
    # REGION | Frame Capture Functions
    # -----------------------------------------------------------------------------

        # FUNCTION | Capture Current View as Frame
        # ------------------------------------------------------------
        def self.capture_frame
            view = Sketchup.active_model.active_view
            view.invalidate                                                      # <-- Mark for redraw
            view.refresh                                                         # <-- Force redraw
            
            filename = format('frame_%06d.png', @@frame_counter)                 # <-- Frame filename
            filepath = File.join(EXPORT_DIR, filename)                           # <-- Full path
            
            view.write_image(
                filename:    filepath,
                width:       WIDTH_PX,
                height:      HEIGHT_PX,
                antialias:   true,
                compression: 9
            )
            
            @@frame_counter += 1                                                 # <-- Increment counter
            
            # Status update every 10 frames
            if @@frame_counter % 10 == 0
                puts "[TimelapseObserver] Captured #{@@frame_counter} frames"
            end
            
        rescue => e
            puts "[TimelapseObserver] Capture error: #{e.message}"
        end
        # ------------------------------------------------------------

    # endregion -------------------------------------------------------------------

    # -----------------------------------------------------------------------------
    # REGION | Recording Control Functions
    # -----------------------------------------------------------------------------

        # HELPER FUNCTION | Check if Recording
        # ------------------------------------------------------------
        def self.running?
            !@@timer.nil?                                                        # <-- Return true if timer exists
        end
        # ------------------------------------------------------------

        # FUNCTION | Start Observing and Recording
        # ------------------------------------------------------------
        def self.start
            return if running?                                                   # <-- Exit if already running
            
            # Select main model file to observe
            @@source_path = UI.openpanel(
                'Select your MAIN MODEL file to observe',
                nil,
                'SketchUp Files|*.skp||'
            )
            return unless @@source_path && File.exist?(@@source_path)            # <-- Exit if cancelled
            
            # Clear the mirror model
            model = Sketchup.active_model
            model.entities.clear!                                                # <-- Clear all entities
            model.definitions.purge_unused                                       # <-- Clean definitions
            
            # Set up scene
            @@scene_page = ensure_helper_scene                                   # <-- Create/get scene
            
            # Reset counters
            @@frame_counter = 0                                                  # <-- Reset frame count
            @@reload_count = 0                                                   # <-- Reset reload count
            @@last_mtime = Time.at(0)                                           # <-- Reset timestamp
            
            # Initial load
            load_model_content                                                   # <-- Load first time
            
            # Start monitoring timer
            @@timer = UI.start_timer(CHECK_INTERVAL, true) { check_and_reload }  # <-- Start timer
            
            # Create REC indicator
            create_overlay                                                       # <-- Show REC
            
            puts "\n[TimelapseObserver] Started observing: #{File.basename(@@source_path)}"
            puts "[TimelapseObserver] Checking every #{CHECK_INTERVAL}s"
            puts "[TimelapseObserver] Frames saved to: #{EXPORT_DIR}"
        end
        # ------------------------------------------------------------

        # FUNCTION | Stop Observing and Recording
        # ------------------------------------------------------------
        def self.stop
            return unless running?                                               # <-- Exit if not running
            
            UI.stop_timer(@@timer)                                               # <-- Stop timer
            @@timer = nil                                                        # <-- Clear reference
            remove_overlay                                                       # <-- Remove REC
            
            puts "\n[TimelapseObserver] Stopped"
            puts "[TimelapseObserver] Total frames: #{@@frame_counter}"
            puts "[TimelapseObserver] Total reloads: #{@@reload_count}"
        end
        # ------------------------------------------------------------

        # SUB FUNCTION | Timer Callback - Check and Reload
        # ------------------------------------------------------------
        def self.check_and_reload
            load_model_content                                                   # <-- Check and load if changed
        rescue => e
            puts "[TimelapseObserver] Check error: #{e.message}"
        end
        # ------------------------------------------------------------

    # endregion -------------------------------------------------------------------

    # -----------------------------------------------------------------------------
    # REGION | Overlay Display Functions
    # -----------------------------------------------------------------------------

        # CLASS | Recording Indicator Overlay
        # ------------------------------------------------------------
        class RecOverlay < Sketchup::Overlay
            def initialize
                super(ValeDesignSuite::TimelapseObserver::EXTENSION_ID, 'REC')
            end
            
            def draw(view)
                # Draw REC indicator in top-right
                margin = 15                                                      # <-- Edge margin
                radius = 8                                                       # <-- Dot radius
                
                cx = view.vpwidth - margin - radius                              # <-- X position
                cy = margin + radius                                              # <-- Y position
                
                # Draw red circle
                pts = []
                segments = 16                                                     # <-- Circle segments
                (0..segments).each do |i|
                    angle = (i * 2.0 * Math::PI) / segments                      # <-- Angle
                    x = cx + radius * Math.cos(angle)                            # <-- X coordinate
                    y = cy + radius * Math.sin(angle)                            # <-- Y coordinate  
                    pts << Geom::Point3d.new(x, y, 0)                           # <-- Add point
                end
                
                view.drawing_color = [255, 0, 0, 255]                            # <-- Red color
                view.draw2d(GL_POLYGON, pts)                                     # <-- Draw filled circle
                
                # Draw REC text
                view.draw_text(
                    Geom::Point3d.new(cx - radius - 35, cy - 6, 0),            # <-- Text position
                    "REC",                                                        # <-- Text
                    {
                        color: [255, 0, 0, 255],                                 # <-- Red text
                        size: 12,                                                # <-- Font size
                        bold: true                                                # <-- Bold font
                    }
                )
            end
        end
        # ------------------------------------------------------------

        # FUNCTION | Create Recording Overlay
        # ------------------------------------------------------------
        def self.create_overlay
            return if @@overlay                                                  # <-- Exit if exists
            @@overlay = RecOverlay.new                                           # <-- Create overlay
            Sketchup.active_model.overlays.add(@@overlay)                       # <-- Add to model
        end
        # ------------------------------------------------------------

        # FUNCTION | Remove Recording Overlay
        # ------------------------------------------------------------
        def self.remove_overlay
            return unless @@overlay                                              # <-- Exit if not exists
            Sketchup.active_model.overlays.remove(@@overlay)                     # <-- Remove overlay
            @@overlay = nil                                                      # <-- Clear reference
        end
        # ------------------------------------------------------------

    # endregion -------------------------------------------------------------------

    # -----------------------------------------------------------------------------
    # REGION | Menu Integration
    # -----------------------------------------------------------------------------

        unless file_loaded?(__FILE__)
            # Create menu command
            cmd = UI::Command.new('Timelapse Observer (Mirror)') { 
                ValeDesignSuite::TimelapseObserver.running? ? ValeDesignSuite::TimelapseObserver.stop : ValeDesignSuite::TimelapseObserver.start 
            }
            cmd.set_validation_proc { 
                ValeDesignSuite::TimelapseObserver.running? ? MF_CHECKED : MF_UNCHECKED 
            }
            cmd.tooltip = "Observe main model and record timelapse"
            cmd.status_bar_text = "Start/stop timelapse observation"
            
            UI.menu('Extensions').add_item(cmd)
            
            # Clean stop on quit
            Sketchup.add_observer(
                Class.new(Sketchup::AppObserver) {
                    def onQuit
                        ValeDesignSuite::TimelapseObserver.stop
                    end
                }.new
            )
            
            file_loaded(__FILE__)
        end

    # endregion -------------------------------------------------------------------

  end # TimelapseObserver
end # ValeDesignSuite