# =============================================================================
# TIMELAPSE SAVER - MAIN MODEL SCRIPT
# =============================================================================
#
# FILE       : TimelapseSaver_MainModel.rb
# MODULE     : ValeDesignSuite::TimelapseSaver
# AUTHOR     : Adam Noble - Noble Architecture
# PURPOSE    : Lightweight auto-save for main model during timelapse recording
# CREATED    : 2025
#
# DESCRIPTION:
# - Minimal impact script that runs in your MAIN working model
# - Simply saves the model at regular intervals
# - No loading, no mirroring, no performance impact
# - The heavy lifting is done by the mirror instance
#
# =============================================================================

require 'sketchup.rb'

module ValeDesignSuite
  module TimelapseSaver

    # MODULE CONSTANTS | Configuration Settings
    # ------------------------------------------------------------
    SAVE_INTERVAL           =   10.0                                             # <-- Seconds between saves
    # ------------------------------------------------------------

    @@timer                 =   nil                                              # <-- Timer reference
    @@save_count            =   0                                                # <-- Save counter for status

    # -----------------------------------------------------------------------------
    # REGION | Timer Control Functions
    # -----------------------------------------------------------------------------

        # HELPER FUNCTION | Check if Timer is Running
        # ------------------------------------------------------------
        def self.running?
            !@@timer.nil?                                                        # <-- Return true if timer exists
        end
        # ------------------------------------------------------------

        # FUNCTION | Start Auto-Save Timer
        # ------------------------------------------------------------
        def self.start
            return if running?                                                   # <-- Exit if already running
            
            model = Sketchup.active_model
            unless model.path && !model.path.empty?
                UI.messagebox("Please save your model first before starting timelapse.")
                return
            end
            
            @@save_count = 0                                                     # <-- Reset counter
            @@timer = UI.start_timer(SAVE_INTERVAL, true) { save_model }        # <-- Start timer
            
            puts "\n[TimelapseSaver] Started - saving every #{SAVE_INTERVAL}s"
            puts "[TimelapseSaver] Model: #{File.basename(model.path)}"
            UI.messagebox("Timelapse Started!\n\nYour model will auto-save every #{SAVE_INTERVAL} seconds.\nWork normally - no performance impact!\n\nOpen the mirror file in another SketchUp to record.")
        end
        # ------------------------------------------------------------

        # FUNCTION | Stop Auto-Save Timer
        # ------------------------------------------------------------
        def self.stop
            return unless running?                                               # <-- Exit if not running
            
            UI.stop_timer(@@timer)                                               # <-- Stop the timer
            @@timer = nil                                                        # <-- Clear timer reference
            puts "\n[TimelapseSaver] Stopped after #{@@save_count} saves"
        end
        # ------------------------------------------------------------

        # SUB FUNCTION | Save the Model
        # ------------------------------------------------------------
        def self.save_model
            model = Sketchup.active_model
            return unless model.path && !model.path.empty?                      # <-- Skip if no path
            
            model.save                                                           # <-- Save the model
            @@save_count += 1                                                    # <-- Increment counter
            
            # Subtle status update every 6 saves (once per minute at 10s interval)
            if @@save_count % 6 == 0
                puts "[TimelapseSaver] #{@@save_count} saves completed"
            end
        rescue => e
            puts "[TimelapseSaver] ERROR: #{e.message}"
            stop                                                                 # <-- Stop on error
        end
        # ------------------------------------------------------------

    # endregion -------------------------------------------------------------------

    # -----------------------------------------------------------------------------
    # REGION | Menu Integration
    # -----------------------------------------------------------------------------

        unless file_loaded?(__FILE__)
            # Create menu command
            cmd = UI::Command.new('Timelapse Saver (Main Model)') { 
                ValeDesignSuite::TimelapseSaver.running? ? ValeDesignSuite::TimelapseSaver.stop : ValeDesignSuite::TimelapseSaver.start 
            }
            cmd.set_validation_proc { 
                ValeDesignSuite::TimelapseSaver.running? ? MF_CHECKED : MF_UNCHECKED 
            }
            cmd.tooltip = "Auto-save for timelapse recording"
            cmd.status_bar_text = "Start/stop auto-saving for timelapse"
            
            UI.menu('Extensions').add_item(cmd)
            
            # Stop cleanly on quit
            Sketchup.add_observer(
                Class.new(Sketchup::AppObserver) {
                    def onQuit
                        ValeDesignSuite::TimelapseSaver.stop
                    end
                }.new
            )
            
            file_loaded(__FILE__)
        end

    # endregion -------------------------------------------------------------------

  end # TimelapseSaver
end # ValeDesignSuite