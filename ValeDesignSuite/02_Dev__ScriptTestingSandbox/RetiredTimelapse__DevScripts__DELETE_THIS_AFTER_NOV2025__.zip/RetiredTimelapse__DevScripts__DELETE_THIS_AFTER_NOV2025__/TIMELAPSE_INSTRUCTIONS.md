# Timelapse Recording System - New Architecture

## Overview
This new system completely eliminates performance issues by separating the recording from your main modeling work.

## Components

### 1. **TimelapseSaver_MainModel.rb** (Main Model)
- Lightweight script that runs in your working model
- Simply auto-saves every 10 seconds
- **ZERO** performance impact - just a normal save operation
- No loading, no mirroring, no lag

### 2. **TimelapseObserver_Mirror.rb** (Separate SketchUp Instance)  
- Runs in a second SketchUp window
- Monitors your main model file for changes
- Reloads and captures frames automatically
- All heavy processing happens here, not in your working model

## Setup Instructions

### Step 1: Install Scripts
1. Copy both scripts to your SketchUp Plugins directory:
   - `TimelapseSaver_MainModel.rb`
   - `TimelapseObserver_Mirror.rb`

### Step 2: Start Recording

#### In Your Main Model:
1. Open your project in SketchUp
2. **IMPORTANT**: Save your model first (it needs a file path)
3. Go to `Extensions > Timelapse Saver (Main Model)`
4. Click to start (checkmark appears when running)
5. Work normally - no performance impact!

#### In a Second SketchUp Instance:
1. Open a new SketchUp window
2. Go to `Extensions > Timelapse Observer (Mirror)`
3. Select your main model file when prompted
4. The mirror will start observing and recording

## How It Works

```
Main Model (You Work Here)          Mirror Instance (Records Here)
    |                                        |
    | Auto-saves every 10s                  | Checks for changes every 2s
    |                                        |
    v                                        v
Main.skp file  ----------------->  Reloads when changed
                                            |
                                            v
                                    Captures frame to PNG
                                            |
                                            v
                                    Video__ExportsTemporary/
                                        frame_000001.png
                                        frame_000002.png
                                        etc...
```

## Benefits

1. **Zero Performance Impact**: Your main model just saves normally
2. **Clean Separation**: Recording happens in separate process
3. **Reliable**: No complex synchronization or file locking
4. **Flexible**: Can stop/start recording without affecting modeling
5. **Scene Support**: Automatically creates and uses TimelapseVideo__HelperScene

## Frame Output

Frames are saved to:
```
ValeDesignSuite/02_Dev__ScriptTestingSandbox/Video__ExportsTemporary/
```

Format: `frame_XXXXXX.png` (1920x1080)

## Creating the Video

Use any video editor or ffmpeg to combine the PNG frames:

```bash
ffmpeg -framerate 30 -i frame_%06d.png -c:v libx264 -pix_fmt yuv420p output.mp4
```

## Tips

- The mirror instance will show a red "REC" indicator when recording
- First load will zoom to extents and save camera position
- You can minimize the mirror window - it still records
- Close the mirror instance to stop recording
- Check frame count in Ruby Console for progress

## Troubleshooting

### "Please save your model first"
- Your main model needs to be saved to disk before starting

### Frames not appearing
- Check the export directory exists
- Ensure both scripts are running (checkmarks in menu)

### Performance still slow
- Make sure you're using the new scripts, not the old ones
- Increase the save interval in TimelapseSaver_MainModel.rb if needed