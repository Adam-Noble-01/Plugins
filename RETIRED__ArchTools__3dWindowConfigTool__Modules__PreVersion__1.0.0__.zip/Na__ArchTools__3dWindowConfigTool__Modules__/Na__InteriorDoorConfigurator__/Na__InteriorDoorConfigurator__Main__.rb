# =============================================================================
# NA INTERIOR DOOR CONFIGURATOR - MAIN ORCHESTRATOR
# =============================================================================
#
# FILE       : Na__InteriorDoorConfigurator__Main__.rb
# NAMESPACE  : Na__InteriorDoorConfigurator
# MODULE     : Na__InteriorDoorConfigurator
# AUTHOR     : Noble Architecture
# PURPOSE    : Entry point for the Interior Door tab. Loads sub-modules,
#              owns module-level constants, and wires up dialog callbacks.
# CREATED    : 01-May-2026
#
# DESCRIPTION:
# - Sole entry point required by the parent Window Configurator tool when the
#   user activates the Interior Doors tab in the dialog.
# - Centralises every constant the door subsystem needs (paths, dictionary
#   keys, default ADR identifiers, default configuration JSON).
# - Exposes a single public initialiser, na_init_door_callbacks(dialog),
#   that the parent DialogManager calls after the HtmlDialog has been shown.
# - Stays out of the way of the Window Configurator: it does not modify any
#   global state and never touches @window_component or window dictionaries.
#
# DEPENDENCIES (loaded in dependency order, helpers first):
# - Na__InteriorDoorConfigurator__DebugTools__
# - Na__InteriorDoorConfigurator__TagManager__
# - Na__InteriorDoorConfigurator__AssetLibrary__
# - Na__InteriorDoorConfigurator__GeometryHelpers__
# - Na__InteriorDoorConfigurator__DataSerializer__
# - Na__InteriorDoorConfigurator__GeometryBuilders__
# - Na__InteriorDoorConfigurator__ArchitraveBuilder__
# - Na__InteriorDoorConfigurator__HandleBuilder3D__
# - Na__InteriorDoorConfigurator__FuseLiningParts__
# - Na__InteriorDoorConfigurator__DoorAssemblyComposer__
# - Na__InteriorDoorConfigurator__GeometryEngine__
# - 07__PluginCore__MeasurmentToolsModules/Na__MeasurementTools__ThreePointOpeningTool__
# - Na__InteriorDoorConfigurator__DialogRouter__
#
# NAMING CONVENTION:
# - All custom identifiers use Na__ or na_ prefix.
#
# =============================================================================

require 'json'
require 'sketchup.rb'

require_relative 'Na__InteriorDoorConfigurator__DebugTools__'
require_relative 'Na__InteriorDoorConfigurator__TagManager__'
require_relative 'Na__InteriorDoorConfigurator__AssetLibrary__'
require_relative 'Na__InteriorDoorConfigurator__GeometryHelpers__'

module Na__InteriorDoorConfigurator

# -----------------------------------------------------------------------------
# REGION | Module References
# -----------------------------------------------------------------------------

    DebugTools     = Na__InteriorDoorConfigurator::Na__DebugTools
    TagManager     = Na__InteriorDoorConfigurator::Na__TagManager
    AssetLibrary   = Na__InteriorDoorConfigurator::Na__AssetLibrary

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Module Constants - Path Resolution
# -----------------------------------------------------------------------------

    # MODULE CONSTANTS | Plugin Layout Paths
    # ------------------------------------------------------------
    # Door UI markup lives directly inside the parent
    # Na__WindowConfiguratorTool__UiLayout__.html (page-swap tab panel),
    # so no fragment HTML is loaded from here.
    NA_MODULE_ROOT_PATH         = File.dirname(__FILE__).freeze                # <-- Folder containing this file
    NA_ASSETS_ROOT_PATH         = File.join(NA_MODULE_ROOT_PATH, "04__InteriorDoorAssets").freeze
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Module Constants - ADR Door ID System
# -----------------------------------------------------------------------------

    # MODULE CONSTANTS | Door ID Format
    # ------------------------------------------------------------
    NA_DOOR_ID_PREFIX            = "ADR".freeze                                # <-- ADR-series door codes
    NA_DOOR_ID_REGEX             = /^ADR\d{3}$/.freeze                         # <-- Validation pattern
    NA_DOOR_ID_FORMAT            = "ADR%03d".freeze                            # <-- sprintf format
    # ---------------------------------------------------------------

    # MODULE CONSTANTS | Component Naming Conventions (TrueVision compatible)
    # ------------------------------------------------------------
    NA_DEFINITION_SUFFIX_DOOR    = "__InteriorDoor__".freeze                   # <-- e.g. ADR001__InteriorDoor__
    NA_GROUP_NAME_ADR_OUTER      = "ADR001__InternalDoor".freeze               # <-- TrueVision outer assembly
    NA_GROUP_NAME_MOD_PANEL      = "MOD001__ROT__90-Deg__DoorPanel".freeze     # <-- TrueVision rotation modifier
    NA_GROUP_NAME_ROT_HINGE      = "ROT001__RotationPoint__DoorHingeCentre".freeze
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Module Constants - Dictionary Keys
# -----------------------------------------------------------------------------

    # MODULE CONSTANTS | Definition / Instance Dictionary Names
    # ------------------------------------------------------------
    NA_DOOR_INFO_DICT            = "Na__DoorConfiguratorInfo".freeze           # <-- Dictionary on ComponentInstance
    NA_DOOR_DEF_DICT_PREFIX      = "Na__DoorConfigurator_".freeze              # <-- Prefix for ComponentDefinition dict
    # ---------------------------------------------------------------

    # MODULE CONSTANTS | Dictionary Keys (instance-side)
    # ------------------------------------------------------------
    NA_KEY_DOOR_ID               = "DoorID".freeze                             # <-- Instance attribute key
    NA_KEY_SU_INSTANCE_NAME      = "SketchUpInstanceName".freeze
    NA_KEY_SU_DEFINITION_NAME    = "SketchUpDefinitionName".freeze
    # ---------------------------------------------------------------

    # MODULE CONSTANTS | Dictionary Keys (definition-side, three blocks)
    # ------------------------------------------------------------
    NA_KEY_DOOR_METADATA         = "Na__DoorMetadata".freeze
    NA_KEY_DOOR_COMPONENTS       = "Na__DoorComponents".freeze
    NA_KEY_DOOR_CONFIGURATION    = "Na__DoorConfiguration".freeze
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Module Constants - Default Material IDs
# -----------------------------------------------------------------------------

    # MODULE CONSTANTS | Default Material IDs (resolved against MaterialManager)
    # ------------------------------------------------------------
    NA_DEFAULT_LINING_MATERIAL_ID      = "MAT120__GenericWood".freeze          # <-- Default lining material
    NA_DEFAULT_PANEL_MATERIAL_ID       = "MAT120__GenericWood".freeze          # <-- Default door panel material
    NA_DEFAULT_ARCHITRAVE_MATERIAL_ID  = "MAT120__GenericWood".freeze          # <-- Default architrave material
    NA_DEFAULT_HANDLE_MATERIAL_ID      = "MAT612__Brass".freeze                # <-- Default handle material
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Module Constants - Default Door Configuration JSON
# -----------------------------------------------------------------------------

    # MODULE CONSTANTS | Default Door Configuration
    # ------------------------------------------------------------
    # Mirrors the structure of NA_DEFAULT_CONFIG_JSON in the Window
    # Configurator. Three top-level blocks:
    #   * Na__DoorMetadata       (array, mirrors windowMetadata)
    #   * Na__DoorComponents     (array, mirrors windowComponents - reserved)
    #   * Na__DoorConfiguration  (hash,  mirrors windowConfiguration)
    # All numeric configuration values are millimetres unless suffixed.
    NA_DEFAULT_DOOR_CONFIG = {
        "Na__DoorMetadata" => [
            {
                "Na__Door__UniqueId"     => nil,
                "Na__Door__Name"         => "New Interior Door",
                "Na__Door__Description"  => "",
                "Na__Door__Notes"        => "Created with Na Interior Door Configurator",
                "Na__Door__CreatedDate"  => nil,
                "Na__Door__LastModified" => nil
            }
        ],
        "Na__DoorComponents" => [],
        "Na__DoorConfiguration" => {
            "Na__DoorConfig__OpeningWidth_mm"        => 850,
            "Na__DoorConfig__OpeningHeight_mm"       => 2100,
            "Na__DoorConfig__WallDepth_mm"           => 105,
            "Na__DoorConfig__LiningThickness_mm"     => 35,
            "Na__DoorConfig__LiningFaceOffset_mm"    => 0,
            "Na__DoorConfig__PanelThickness_mm"      => 40,
            "Na__DoorConfig__PanelFloorClearance_mm" => 10,
            "Na__DoorConfig__ArchitraveProfileKey"   => "Na__InteriorDoor__Architrave__Default",
            "Na__DoorConfig__ArchitraveOffset_mm"    => 5,
            "Na__DoorConfig__ArchitraveFrontEnabled" => true,
            "Na__DoorConfig__ArchitraveBackEnabled"  => true,
            "Na__DoorConfig__SwingSide"              => "Left",
            "Na__DoorConfig__SwingDirection"         => "Inward",
            "Na__DoorConfig__HandleAssetKey"         => "Na__InteriorDoor__Handle__Default",
            "Na__DoorConfig__HandleHeight_mm"        => 1050,
            "Na__DoorConfig__CreateOpenStateCopy"    => true,
            "Na__DoorConfig__FuseLining"             => true,
            "Na__DoorConfig__LiningMaterialId"       => "MAT120__GenericWood",
            "Na__DoorConfig__PanelMaterialId"        => "MAT120__GenericWood",
            "Na__DoorConfig__ArchitraveMaterialId"   => "MAT120__GenericWood",
            "Na__DoorConfig__HandleMaterialId"       => "MAT612__Brass"
        }
    }.freeze
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Late-Bound Sub-Module Loading
# -----------------------------------------------------------------------------

    # FUNCTION | Load Sub-Modules in Dependency Order (Late Bound)
    # ------------------------------------------------------------
    # Called by na_init_door_callbacks the first time the door tab is
    # used, so that the parent tool can boot without any door module
    # loaded if the user never opens the door tab. All requires use
    # require_relative against this file's directory.
    def self.na_require_door_modules
        return if @na_door_modules_loaded

        require_relative 'Na__InteriorDoorConfigurator__DataSerializer__'
        require_relative 'Na__InteriorDoorConfigurator__GeometryBuilders__'
        require_relative 'Na__InteriorDoorConfigurator__ArchitraveBuilder__'
        require_relative 'Na__InteriorDoorConfigurator__HandleBuilder3D__'
        require_relative 'Na__InteriorDoorConfigurator__FuseLiningParts__'
        require_relative 'Na__InteriorDoorConfigurator__DoorAssemblyComposer__'
        require_relative 'Na__InteriorDoorConfigurator__GeometryEngine__'
        require_relative File.join(                                            # <-- Now lives in shared 07__PluginCore__MeasurmentToolsModules
            "..",
            "07__PluginCore__MeasurmentToolsModules",
            "Na__MeasurementTools__ThreePointOpeningTool__"
        )
        require_relative 'Na__InteriorDoorConfigurator__DialogRouter__'

        AssetLibrary.na_set_assets_root_path(NA_ASSETS_ROOT_PATH)

        @na_door_modules_loaded = true
        DebugTools.na_debug_door("All door sub-modules loaded")
    end
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Public API - Dialog Wiring
# -----------------------------------------------------------------------------

    # FUNCTION | Initialise Door-Tab Action Callbacks on the Active Dialog
    # ------------------------------------------------------------
    # Bootstraps the door tab against the parent tool's shared HtmlDialog
    # by delegating to Na__DialogRouter.na_init, which caches the dialog
    # reference and registers every door-side action callback (createDoor,
    # updateDoor, liveUpdateDoor, measureDoorOpening, ...). Safe to call
    # repeatedly - SketchUp replaces same-name handlers on each call.
    #
    # @param dialog [UI::HtmlDialog] The shared dialog instance
    # @return [Boolean] True on success, false on failure
    def self.na_init_door_callbacks(dialog)
        return false unless dialog
        na_require_door_modules

        Na__InteriorDoorConfigurator::Na__DialogRouter.na_init(
            dialog, NA_DEFAULT_DOOR_CONFIG
        )
        DebugTools.na_debug_door("Door tab callbacks registered on dialog")
        true
    rescue StandardError => e
        DebugTools.na_debug_error("na_init_door_callbacks failed", e) if defined?(DebugTools)
        puts "[NA_DOOR_INIT] Failed to register door callbacks : #{e.message}"
        puts e.backtrace.first(10).join("\n") if e.backtrace
        false
    end
    # ---------------------------------------------------------------

    # FUNCTION | Load a Door Selection into the Dialog (Observer Hook)
    # ------------------------------------------------------------
    # Called by the shared SelectionObserver when a component instance
    # carrying a DoorID is selected.
    #
    # @param instance [Sketchup::ComponentInstance] The selected door instance
    # @param door_id [String] The validated door ID (e.g. "ADR001")
    def self.na_load_door_into_dialog(instance, door_id)
        na_require_door_modules
        Na__InteriorDoorConfigurator::Na__DialogRouter.na_load_door_into_dialog(instance, door_id)
    end
    # ---------------------------------------------------------------

    # FUNCTION | Clear the Door Tab State on Empty Selection
    # ------------------------------------------------------------
    def self.na_clear_door_from_dialog
        return unless @na_door_modules_loaded
        Na__InteriorDoorConfigurator::Na__DialogRouter.na_clear_door_from_dialog
    end
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

# -----------------------------------------------------------------------------
# REGION | Public API - Default Configuration Access
# -----------------------------------------------------------------------------

    # FUNCTION | Return a Deep Copy of the Default Door Configuration
    # ------------------------------------------------------------
    # @return [Hash] Deep clone safe to mutate
    def self.na_default_door_config
        Marshal.load(Marshal.dump(NA_DEFAULT_DOOR_CONFIG))
    end
    # ---------------------------------------------------------------

    # FUNCTION | Return the Default Door Configuration as a JSON String
    # ------------------------------------------------------------
    # @return [String] JSON serialisation suitable for sending to the dialog
    def self.na_default_door_config_json
        JSON.generate(NA_DEFAULT_DOOR_CONFIG)
    end
    # ---------------------------------------------------------------

# endregion -------------------------------------------------------------------

end # module Na__InteriorDoorConfigurator

# =============================================================================
# END OF FILE
# =============================================================================
