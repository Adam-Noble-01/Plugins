(function() {
    'use strict';

    // -------------------------------------------------------------------------
    // REGION | Configuration State
    // -------------------------------------------------------------------------

    const Na__Ui__Config = {
        profileOptions: [
            { value: '', label: 'Select profile (placeholder)' }
        ],
        toggleDefinitions: {},
        pathModeOptions: [
            { value: 'selection', label: 'Use current selection' },
            { value: 'interactive', label: 'Interactive path picking' }
        ],
        profileSourceModeOptions: [
            { value: 'library', label: 'Profile Library' },
            { value: 'scene', label: 'Scene Pick (Group/Component Face)' }
        ],
        defaults: {
            profileKey: '',
            profileSourceMode: 'library',
            pathMode: 'interactive',
            rotationStep: 0,
            isPreviewEnabled: true,
            toggleStates: {}
        }
    };

    // endregion ----------------------------------------------------------------

    // -------------------------------------------------------------------------
    // REGION | Profile Options - Setter
    // -------------------------------------------------------------------------

    function Na__Ui__SetProfileOptions(profileOptions) {
        if (!Array.isArray(profileOptions) || profileOptions.length === 0) {
            Na__Ui__Config.profileOptions = [{ value: '', label: 'No enabled profiles found' }];
            return;
        }

        Na__Ui__Config.profileOptions = profileOptions.map(function(profileOption) {
            const category = profileOption.category;
            const label = category && category !== 'Profile2D'
                ? category + ' :: ' + profileOption.displayName
                : profileOption.displayName;

            return {
                value: profileOption.profileKey,
                label: label
            };
        });
    }

    // endregion ----------------------------------------------------------------

    // -------------------------------------------------------------------------
    // REGION | Public Exports
    // -------------------------------------------------------------------------

    window.Na__ProfilePathTracer__Ui__Config = Na__Ui__Config;
    window.Na__ProfilePathTracer__Ui__SetProfileOptions = Na__Ui__SetProfileOptions;

    // endregion ----------------------------------------------------------------
})();
