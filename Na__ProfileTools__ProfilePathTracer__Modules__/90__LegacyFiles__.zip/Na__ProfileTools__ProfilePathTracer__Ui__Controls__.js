(function() {
    'use strict';

    // -------------------------------------------------------------------------
    // REGION | Html Helpers
    // -------------------------------------------------------------------------

    function Na__Ui__BuildOptionsHtml(options, selectedValue) {
        return options.map(function(option) {
            const isSelected = String(option.value) === String(selectedValue) ? ' selected' : '';
            return '<option value="' + option.value + '"' + isSelected + '>' + option.label + '</option>';
        }).join('');
    }

    function Na__Ui__BuildToggleRowsHtml(toggleDefinitions, toggleStates) {
        const toggleKeys = Object.keys(toggleDefinitions || {});
        if (toggleKeys.length === 0) return '';

        return toggleKeys.map(function(toggleKey) {
            const toggleMeta = toggleDefinitions[toggleKey] || {};
            const isChecked = !!toggleStates[toggleKey];
            const checkedAttr = isChecked ? ' checked' : '';
            const safeLabel = toggleMeta.text || toggleKey;
            const safeDescription = toggleMeta.description || '';
            const id = 'naToggle__' + toggleKey;

            return [
                '<div class="naFormRow">',
                '  <label for="' + id + '">' + safeLabel + '</label>',
                '  <input class="naInput naToggleInput" data-na-toggle-key="' + toggleKey + '" id="' + id + '" type="checkbox"' + checkedAttr + ' title="' + safeDescription + '">',
                '</div>'
            ].join('');
        }).join('');
    }

    // endregion ----------------------------------------------------------------

    // -------------------------------------------------------------------------
    // REGION | Controls Renderer
    // -------------------------------------------------------------------------

    function Na__Ui__RenderControls(state) {
        const config = window.Na__ProfilePathTracer__Ui__Config;
        const profileValue = state.profileKey || config.defaults.profileKey;
        const profileSourceModeValue = state.profileSourceMode || config.defaults.profileSourceMode || 'library';
        const pathModeValue = state.pathMode || config.defaults.pathMode;
        const previewChecked = state.isPreviewEnabled ? ' checked' : '';
        const toggleDefinitions = state.toggleDefinitions || config.toggleDefinitions || {};
        const toggleStates = state.toggleStates || config.defaults.toggleStates || {};
        const rotationStep = Number(state.rotationStep || 0) % 4;
        const rotationDegrees = rotationStep * 90;
        const isSceneMode = profileSourceModeValue === 'scene';
        const sceneStatus = state.sceneProfileStatus || {};
        const sceneProfileName = sceneStatus.displayName || 'No scene profile selected';
        const sceneProfileReady = sceneStatus.isValid === true;
        const sceneReadyClass = sceneProfileReady ? 'naSceneStatus--ready' : 'naSceneStatus--pending';
        const sceneHint = sceneProfileReady ? 'Scene source ready' : 'Pick scene source';

        return [
            '<div class="naFormRow">',
            '  <label for="naProfileSourceModeSelect">Profile Source</label>',
            '  <select class="naSelect" id="naProfileSourceModeSelect">',
            Na__Ui__BuildOptionsHtml(config.profileSourceModeOptions, profileSourceModeValue),
            '  </select>',
            '</div>',
            '<div class="naFormRow">',
            '  <label for="naProfileSelect">Profile</label>',
            '  <select class="naSelect" id="naProfileSelect">',
            Na__Ui__BuildOptionsHtml(config.profileOptions, profileValue),
            '  </select>',
            '</div>',
            '<div class="naSceneSourceWrap' + (isSceneMode ? '' : ' naSceneSourceWrap--hidden') + '">',
            '  <div class="naSceneStatus ' + sceneReadyClass + '">' + sceneHint + ': ' + sceneProfileName + '</div>',
            '  <div class="naSceneActions">',
            '    <button class="naButton" id="naBtnPickSceneProfile">Pick Scene Profile</button>',
            '    <button class="naButton naButtonSecondary" id="naBtnClearSceneProfile">Clear</button>',
            '  </div>',
            '</div>',
            '<div class="naFormRow">',
            '  <label for="naPathModeSelect">Path Mode</label>',
            '  <select class="naSelect" id="naPathModeSelect">',
            Na__Ui__BuildOptionsHtml(config.pathModeOptions, pathModeValue),
            '  </select>',
            '</div>',
            '<div class="naFormRow">',
            '  <label for="naPreviewEnabled">Preview</label>',
            '  <input class="naInput" id="naPreviewEnabled" type="checkbox"' + previewChecked + '>',
            '</div>',
            Na__Ui__BuildToggleRowsHtml(toggleDefinitions, toggleStates),
            '<div class="naActions">',
            '  <button class="naButton naButtonRotate" id="naBtnRotateProfile">Rotate 90 deg (' + rotationDegrees + ' deg)</button>',
            '  <button class="naButton naButtonPrimary" id="naBtnGenerate">Generate</button>',
            '  <button class="naButton naButtonCreate" id="naBtnCreateProfile">Create New Profile</button>',
            '</div>'
        ].join('');
    }

    // endregion ----------------------------------------------------------------

    // -------------------------------------------------------------------------
    // REGION | Create Profile Form Renderer
    // -------------------------------------------------------------------------

    function Na__Ui__RenderCreateProfileForm(validationResult) {
        var now = new Date();
        var day = String(now.getDate()).padStart(2, '0');
        var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        var month = months[now.getMonth()];
        var year = now.getFullYear();
        var hours = String(now.getHours()).padStart(2, '0');
        var minutes = String(now.getMinutes()).padStart(2, '0');
        var timestamp = day + '-' + month + '-' + year + '__' + hours + ':' + minutes;

        var summary = 'Selection: ' + (validationResult.faceCount || 0) + ' faces, ' +
                      (validationResult.edgeCount || 0) + ' edges, ' +
                      (validationResult.vertexCount || 0) + ' vertices';

        return [
            '<div class="naCreateProfileForm">',
            '  <div class="naValidationSummary">' + summary + '</div>',
            '  <div class="naFormRow">',
            '    <label for="naMetaProfileName">Profile Name</label>',
            '    <input class="naInput" id="naMetaProfileName" type="text" placeholder="e.g. Gutter Box 200x100">',
            '  </div>',
            '  <div class="naFormRow">',
            '    <label for="naMetaDescription">Description</label>',
            '    <textarea class="naTextarea" id="naMetaDescription" rows="2" placeholder="A brief description of this profile shape"></textarea>',
            '  </div>',
            '  <div class="naFormRow">',
            '    <label for="naMetaKeywords">Keywords</label>',
            '    <input class="naInput" id="naMetaKeywords" type="text" placeholder="gutter, box, 200mm (comma separated)">',
            '  </div>',
            '  <div class="naFormRow">',
            '    <label for="naMetaProfileId">Profile ID</label>',
            '    <input class="naInput" id="naMetaProfileId" type="text" placeholder="PRF001_GutterBox__200x100">',
            '  </div>',
            '  <div class="naFormRow">',
            '    <label>Timestamp</label>',
            '    <input class="naInputReadonly" type="text" value="' + timestamp + '" readonly>',
            '  </div>',
            '  <div class="naFormRow">',
            '    <label>Units</label>',
            '    <input class="naInputReadonly" type="text" value="millimetres" readonly>',
            '  </div>',
            '  <div class="naCreateProfileActions">',
            '    <button class="naButtonSuccess" id="naBtnSaveProfile">Save Profile Data File</button>',
            '    <button class="naButtonSecondary" id="naBtnCancelCreateProfile">Cancel</button>',
            '  </div>',
            '</div>'
        ].join('');
    }

    // endregion ----------------------------------------------------------------

    // -------------------------------------------------------------------------
    // REGION | Public Exports
    // -------------------------------------------------------------------------

    window.Na__ProfilePathTracer__Ui__Controls = {
        Na__Ui__RenderControls: Na__Ui__RenderControls,
        Na__Ui__RenderCreateProfileForm: Na__Ui__RenderCreateProfileForm
    };

    // endregion ----------------------------------------------------------------
})();
